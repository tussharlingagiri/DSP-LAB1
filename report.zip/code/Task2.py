# Tasks:
# Enhance both voice recordings, make it clearer and like a radio show and remove noise.

# To do this, manipulate the amplitudes of the frequency coefficients.

# For both recordings, explain the kind of noise 
# that needs to be removed and what frequency range it has.

# Explain how you would like to improve the speech by looking into loss 
# of bass frequencies with distance and the risk of popping sounds when close.

import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile

REC = {
    '5cm': dict(file='Assignment_1_audio_5cm.wav',
                vowels=[(0.43, 0.67), (1.00, 1.13)],
                cons=[(0.12, 0.22), (0.88, 0.96)],
                noise=(1.22, 1.50),
                f0=[120, 90],                  
                cons_range=(3000, 15000),
                noise_low=80, noise_high=18000),
    '1m':  dict(file='Assignment_1_audio_1m.wav',
                vowels=[(0.55, 0.90), (1.30, 1.50)],
                cons=[(0.95, 1.03), (1.20, 1.30)],
                noise=(0.00, 0.45),
                f0=[120, 95],                  
                cons_range=(2000, 12000),
                noise_low=80, noise_high=15000),
}

def load(path):
    fs, x = wavfile.read(path)
    print(x.dtype)
    x = x.astype(np.float64)
    # return fs, x / np.max(np.abs(x))
    return fs, x / 2147483647.0

def filter_bandwidth_start(initial_frequency,final_frequency,x,fs, key):
    N = len(x) #Number of samples
    print("N:", N)
    X = np.fft.fft(x) #fft of audio signal
    print("X:", len(X))
    f_res = fs / N
    
    k_initial = int(initial_frequency / f_res)
    k_final = int(final_frequency / f_res)
    X[0:k_final] = 1e-12 # temp amplification of audio signal
    X[-k_final:] = 1e-12
    # X_2 = np.fft.fft(x)[:N // 2] / N
    # X_2[k_initial:k_final] = 0 # temp amplification of audio signal
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)
    # plot_annotated(x, fs, key, c, f[1:], X_mag)

    X_filtered = np.fft.ifft(X).real # inverse fft of adjusted signal
    print("filtered X:", len(X_filtered))
    return X_filtered # outputting a complex output array

def filter_bandwidth_end(initial_frequency,final_frequency,x,fs, key):
    N = len(x) #Number of samples
    print("N:", N)
    X = np.fft.fft(x) #fft of audio signal
    print("X:", len(X))
    f_res = fs / N
    
    k_initial = int(initial_frequency / f_res)
    k_final = int(final_frequency / f_res)
    X[k_initial:k_final] = 1e-12 # temp amplification of audio signal
    X[-k_final:-k_initial] = 1e-12
    # X_2 = np.fft.fft(x)[:N // 2] / N
    # X_2[k_initial:k_final] = 0 # temp amplification of audio signal
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)
    # plot_annotated(x, fs, key, c, f[1:], X_mag)

    X_filtered = np.fft.ifft(X).real # inverse fft of adjusted signal
    print("filtered X:", len(X_filtered))
    return X_filtered # outputting a complex output array

def filter_magnitude(x, fs, modifier):
    N = len(x) #Number of samples
    X = np.fft.fft(x) #fft of audio signal
    PSD = np.abs(X) ** 2
    PSD_norm = PSD / np.max(PSD)
    frequency = (fs/N) * np.arange(N)
    L = np.arange(1,np.floor(N/2),dtype='int')
    f_res = fs / N

    plt.figure()
    # PSD_db = 10 * np.log10(PSD_norm[L] + 1e-12)
    # plt.plot(frequency[L], PSD_db)
    plt.plot(frequency[L], PSD_norm[L])

    PSD_norm[int(-len(PSD_norm)/2):] = PSD_norm[:int(len(PSD_norm)/2)][::-1]

    X_filter = np.where(PSD_norm > modifier, 1.0, 0.01) 

    # PSD_norm[int(-len(PSD_norm)/2):] = PSD_norm[:int(len(PSD_norm)/2)][::-1]

    print(len(X_filter))
    print(len(X))
    X = X * X_filter

    plt.figure()
    # PSD_norm = X * np.conj(X) / np.max(PSD)
    X_2 = X[:N // 2] / N
    f = np.arange(N // 2) * f_res
    X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    plt.plot(f[1:],X_mag)

    # plt.figure()
    # plt.plot(frequency[L], PSD_norm[L])

    X_filtered = np.fft.ifft(X).real # inverse fft of adjusted signal
    print("filtered X:", len(X_filtered))
    return X_filtered # outputting a complex output array

    
def boost_amplitude(initial_frequency, final_frequency, x, fs, modifier):
    N = len(x) #Number of samples
    print("N:", N)
    X = np.fft.fft(x) #fft of audio signal
    print("X:", len(X))
    f_res = fs / N
    
    k_initial = int(initial_frequency / f_res)
    k_final = int(final_frequency / f_res)
    X[k_initial:k_final] *= modifier # temp amplification of audio signal
    X[-k_final:-k_initial] *= modifier
    X_filtered = np.fft.ifft(X).real # inverse fft of adjusted signal
    print("filtered X:", len(X_filtered))
    return X_filtered # outputting a complex output array

def plot_time(x, fs, key):
    plt.figure()
    plt.plot(np.arange(len(x)) / fs, x)
    plt.xlabel('Time [s]'); plt.ylabel('Normalised amplitude')
    plt.title(f'Time domain ({key})')

def plot_annotated(x, fs, key, c, f, m):
    # f, m = spectrum_dB(x, fs)
    # f, m = filter_bandwidth(2000,22050,x, fs)
    plt.figure(figsize=(10, 6))
    plt.semilogx(f, m)
    for i, f0 in enumerate(c['f0']):
        plt.axvline(f0, color='r', ls='--',
                    label=f"Vowel fundamentals ({', '.join(map(str, c['f0']))} Hz)" if i == 0 else None)
    plt.axvspan(*c['cons_range'], color='orange', alpha=0.2,
                label=f"Consonants ({c['cons_range'][0]}-{c['cons_range'][1]} Hz)")
    plt.axvspan(f[0], c['noise_low'], color='grey', alpha=0.3,
                label=f"Noise (<{c['noise_low']} Hz, >{c['noise_high']} Hz)")
    plt.axvspan(c['noise_high'], fs / 2, color='grey', alpha=0.3)
    plt.xlabel('Frequency [Hz]'); plt.ylabel('Magnitude [dB]')
    plt.title(f'Annotated spectrum ({key})')
    plt.legend(loc='lower left', fontsize=8)

def plot_boosted(x, fs, key, c):
    # f, m = spectrum_dB(x, fs)
    # f, m = filter_bandwidth(2000,22000,x, fs)#
    print("length of fs", fs)
    f, m = boost_amplitude(2000,22050,x, fs)
    plt.figure(figsize=(10, 6))
    plt.semilogx(f, m)
    for i, f0 in enumerate(c['f0']):
        plt.axvline(f0, color='r', ls='--',
                    label=f"Vowel fundamentals ({', '.join(map(str, c['f0']))} Hz)" if i == 0 else None)
    plt.axvspan(*c['cons_range'], color='orange', alpha=0.2,
                label=f"Consonants ({c['cons_range'][0]}-{c['cons_range'][1]} Hz)")
    plt.axvspan(f[0], c['noise_low'], color='grey', alpha=0.3,
                label=f"Noise (<{c['noise_low']} Hz, >{c['noise_high']} Hz)")
    plt.axvspan(c['noise_high'], fs / 2, color='grey', alpha=0.3)
    plt.xlabel('Frequency [Hz]'); plt.ylabel('Magnitude [dB]')
    plt.title(f'boosted spectrum  ({key})')
    plt.legend(loc='lower left', fontsize=8)

def remove_hvac_noise(x, fs, frame_size=2048, alpha=2.0, beta=0.02):
    hop_size = frame_size // 2  # 50% overlap for smooth blending
    N = len(x)

    n = np.arange(frame_size)
    window = window = 0.5 - 0.5 * np.cos(2 * np.pi * n / (frame_size - 1))
    
    # 1. Capture the noise profile from a known quiet block at the start
    # (Make sure your audio starts with a brief pause where only the HVAC is running)
    noise_block = x[54047:66395] * window
    X_noise = np.fft.fft(noise_block)
    noise_mag = np.abs(X_noise)
    
    output_signal = np.zeros(N)
    
    # 2. Loop through the entire audio file frame-by-frame
    for i in range(0, N - frame_size, hop_size):
        # Extract the current frame from the full audio and apply window
        frame = x[i:i + frame_size] * window
        
        # Convert frame to frequency domain
        X = np.fft.fft(frame)
        mag = np.abs(X)
        
        # Isolate the phase angles so we don't distort timing/speech quality
        phase = X / (mag + 1e-12)
        
        # 3. Subtract the noise profile magnitude from this frame's magnitude
        cleaned_mag = mag - (alpha * noise_mag)
        
        # Apply a spectral floor (beta) so bins aren't forced to absolute zero (prevents harsh artifacts)
        cleaned_mag = np.maximum(cleaned_mag, beta * mag)
        
        # 4. Reconstruct the frame using the cleaned magnitude and original phase
        X_clean = cleaned_mag * phase
        
        # Inverse FFT back to time domain, window again, and add to output
        frame_back = np.fft.ifft(X_clean).real * window
        output_signal[i:i + frame_size] += frame_back
        
    return output_signal

data = {k: load(c['file']) for k, c in REC.items()}

for key, c in REC.items():
    fs, x = data[key]
    # plot_time(x, fs, key)
    N = 66395
    noise_N = N - 54047
    f_res = 44100/N
    f_res_noise = 44100/(66395-5404)
    plot_time(x, fs, key)
    X_noise = x[54047:66395]
    Xn_fft = np.fft.fft(X_noise)[:noise_N // 2] / noise_N
    f = np.arange(noise_N//2) * f_res_noise
    noise_mag = 20 * np.log10(np.abs(Xn_fft[1:]) + 1e-12)
    print(len(noise_mag))

    X_filtered = remove_hvac_noise(x, fs, 66395-54047, alpha=2.0, beta=0.02)

    plt.figure()
    plt.plot(f[1:],noise_mag)

    # plt.figure()
    plot_time(X_filtered,fs,key)

    # plt.figure()
    # X_2 = np.fft.fft(x)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    # X = filter_magnitude(x,fs, 0.002)

    # plt.figure()
    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    # X = filter_bandwidth_end(6000,22050,X,fs, key)

    # plt.figure()
    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    # X = filter_bandwidth_end(1100,1200,X,fs, key)

    # plt.figure()
    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    # X = filter_bandwidth_start(0,250,X,fs, key)

    # plt.figure()
    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    X = boost_amplitude(250,800,X_filtered,fs, 10)

    plt.figure()   
    X_2 = np.fft.fft(X)[:N // 2] / N
    f = np.arange(N // 2) * f_res
    X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    plt.plot(f[1:],X_mag)

    X = boost_amplitude(2000,6000,X,fs, 10)

    plt.figure()
    X_2 = np.fft.fft(X)[:N // 2] / N
    f = np.arange(N // 2) * f_res
    X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    plt.plot(f[1:],X_mag)

    # X = filter_magnitude(X,fs, 0.0005)

    # plt.figure()
    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)

    # X_2 = np.fft.fft(X)[:N // 2] / N
    # f = np.arange(N // 2) * f_res
    # X_mag = 20 * np.log10(np.abs(X_2[1:]) + 1e-12)
    # plt.plot(f[1:],X_mag)
    # plot_time(X, fs, key)         
    # print("fs:",fs)
    # print("x:",x)
    # print(f"{key}: fs={fs}, duration={len(x) / fs:.2f}s, "
    #       f"samples at max={np.sum(np.abs(x) >= 0.999)}")
    # f , m = filter_bandwidth(2000,22050,x, fs)
    audio_int16 = (X * 32767).astype(np.int16)
    if key == '5cm' :
        wavfile.write("filtered_audio_test_5cm.wav", 44100, audio_int16)
    else: wavfile.write("filtered_audio_test_1m.wav", 44100, audio_int16)

    # plot_time(x, fs, key)              
    # plot_annotated(x, fs, key, c, f, m)
    # plot_boosted(x, fs, key, c)
    # filter_bandwidth(1,3000,x,fs,key)
plt.show()